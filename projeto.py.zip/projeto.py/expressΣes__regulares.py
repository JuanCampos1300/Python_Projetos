import re

string = 'isso é um teste de expressão  regular'

print(re.search(r'expressão', string))    # sempre que for escrever uma expressão regular colocar o (r'', varialvel)
print(re.findall(r'teste', string))
print(re.sub(r'teste', '1', string))    

teste = re.compile(r'teste')
print(teste.search(string))    # sempre que for escrever uma expressão regular colocar o (r'', varialvel)
print(teste.findall(string))
print(teste.sub('1', string))  

