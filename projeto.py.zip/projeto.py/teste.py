'''{************************************************
* extrae e deleta primeira ocorrencia substring *
*************************************************}
function DelFirstStr( var Str: String; Ini, Fim: String ): String;
var
     i, f: Integer;
     Ret, Tmp: String;
begin
     Ret := '';
     i   := Pos( Ini, Str );
     if i > 0 then begin
          Tmp := Copy( Str, i + Length( Ini ), Length( Str ) );
          f   := Pos( Fim, Tmp );
          if f > 0 then begin
               Ret := Copy( Tmp, 1, f - 1 );
               Delete( Str, i, f + Length( Fim ) - 1 );
          end;
     end;
     Result := Ret;
end;
'''
#function = def


def teste1000 ():
     frase = ('ola juan, oi joana, oi diego, oi claudio, oi maurico, oi rafael, oi alex, oi joao')
     x = 0
     while x < len(frase):
          x = frase .find('oi', x + 1)
          print(x)
          if 'diego' in frase[0:x]:
               print('achei voçê rapaz!')
               return

          if x == -1:
               print('não achei o diego')
               return x

teste1000()