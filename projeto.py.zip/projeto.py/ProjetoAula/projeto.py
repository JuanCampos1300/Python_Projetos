import pandas as pd 
from twilio.rest import Client

# voce precisa criar uma  conta no twuliio para gerar um SID e um token  para substituir a na variavel, isso serve para enviarmos uma mensagem para o seu smartphone  ou computador;
    # o código no ttwliio já vem pronto, seria esse código:
'''
    from twilio.rest import Client                            #(Essa parte voce coloca nas primeira linha do python)

# Your Account SID from twilio.com/console                     #(Essa parte voce valida o tokem e o SID  que o twilioo disponibiliza no site)
account_sid = "AC4647723f4841a11c4f24ee52c74a74d5"          
# Your Auth Token from twilio.com/console
auth_token  = "your_auth_token"

client = Client(account_sid, auth_token)

message = client.messages.create(                         #(essa parte coloca no if para fazer a função ( alterando os dados)
    to="+15558675309",                                                  
    from_="+15017250604",
    body="Hello from Python!")                            #(body mensagem que quer enviar a pessoa )

print(message.sid)                                          #(essa parte de baixo de onde voce colocou aparte do body)
'''

account_sid = "AC4647723f4841a11c4f24ee52c74a74d5"
auth_token  = "cb347efc7b93308129df7f213256fdae"

client = Client(account_sid, auth_token)

# Passo a passo solução;

# Abrir os arquivos em excel; 
# para abir um aquivo excel só digitar  [import pandas as pd]  (as pd é pandas abreviado)
# função for significa loop

lista_meses = ['Janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho' ]

# for (para cada) nome da variavel ('mes' ou qualquer outro nome ) in (dentro da) nome da variavel ('lista_meses' qualquer outro nome) executa um código ;
# no pythom uma indentação (um espaço) é muito importante, pois indica que tem um código dentro de uma fução;   
for mes in lista_meses:
    tabela_vendas = pd.read_excel(f'{mes}.xlsx')
    print(tabela_vendas)
    if (tabela_vendas['vendas'] > 55000).any():
        vedendor = tabela_vendas.loc[tabela_vendas['vendas'] > 55000, 'vedendor'].values[0]
        vendas = tabela_vendas.loc[ tabela_vendas['vendas'] > 55000, 'vendas'].values[0]
        print(f' no {mes} alguem bateu a meta. Vendedor: {vedendor}, Vendas: {vendas}')
        message = client.messages.create(
            to="+ 5511997944631", 
            from_="+16066136669",
            body= f' no {mes} alguem bateu a meta. Vendedor: {vedendor}, Vendas: {vendas}')
        print(message.sid)

# voce precisa criar uma  conta no twuliio para de dar um SID e um token  para substituir a na variavel 



#. loc localiza uma ou mais linha de uma tabela,  sempre será dentro de [];
#. values  será utilizado no final de .loc  para te dar somente o valor que esta dentro da função;
#  
#. any() significa algum,  algum valor 
# Para cada arquivo , verificar se  se algum valor na coluna vendas, naquele arquivo é maiior  que 55.000,00;

# Se for maior que 55.000,00 enviar um SMS, Com nome, mês e as vendas do vendedor;

# caso for menor o valor, não fazer nada;
 
